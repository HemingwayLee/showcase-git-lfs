# Script to extract/unzip and organize PubTables-1M.
# Remove the -v flag to suppress output to the console.
mkdir -p PubTables-1M-Structure/{images,train,test,val,words}
tar -xzvf PubTables-1M-Structure_Filelists.tar.gz --directory PubTables-1M-Structure/
tar -xzvf PubTables-1M-Structure_Annotations_Test.tar.gz --directory PubTables-1M-Structure/test/
tar -xzvf PubTables-1M-Structure_Annotations_Train.tar.gz --directory PubTables-1M-Structure/train/
tar -xzvf PubTables-1M-Structure_Annotations_Val.tar.gz --directory PubTables-1M-Structure/val/
tar -xzvf PubTables-1M-Structure_Images_Test.tar.gz --directory PubTables-1M-Structure/images/
tar -xzvf PubTables-1M-Structure_Images_Train.tar.gz --directory PubTables-1M-Structure/images/
tar -xzvf PubTables-1M-Structure_Images_Val.tar.gz --directory PubTables-1M-Structure/images/
tar -xzvf PubTables-1M-Structure_Table_Words.tar.gz --directory PubTables-1M-Structure/words/
mkdir -p PubTables-1M-Detection/{images,train,test,val,words}
tar -xzvf PubTables-1M-Detection_Filelists.tar.gz --directory PubTables-1M-Detection/
tar -xzvf PubTables-1M-Detection_Annotations_Test.tar.gz --directory PubTables-1M-Detection/test/
tar -xzvf PubTables-1M-Detection_Annotations_Train.tar.gz --directory PubTables-1M-Detection/train/
tar -xzvf PubTables-1M-Detection_Annotations_Val.tar.gz --directory PubTables-1M-Detection/val/
tar -xzvf PubTables-1M-Detection_Images_Test.tar.gz --directory PubTables-1M-Detection/images/
tar -xzvf PubTables-1M-Detection_Images_Train_Part1.tar.gz --directory PubTables-1M-Detection/images/
tar -xzvf PubTables-1M-Detection_Images_Train_Part2.tar.gz --directory PubTables-1M-Detection/images/
tar -xzvf PubTables-1M-Detection_Images_Val.tar.gz  --directory PubTables-1M-Detection/images/
tar -xzvf PubTables-1M-Detection_Page_Words.tar.gz --directory PubTables-1M-Detection/words/
mkdir PubTables-1M-PDF-Annotations/
tar -xzvf PubTables-1M-PDF_Annotations.tar.gz --directory PubTables-1M-PDF-Annotations
